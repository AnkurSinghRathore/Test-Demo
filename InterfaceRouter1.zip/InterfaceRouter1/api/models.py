from django.db import models
# Create your models here.
from django.conf import settings

class RouterDetails(models.Model):
    class Meta:
        db_table = 'router_details'

    id = models.AutoField(primary_key=True)
    sapid = models.CharField(max_length=200,db_index = True)
    hostname = models.CharField(max_length=100,db_index = True)
    loopback_ipv4 = models.CharField(max_length=100,db_index = True)
    mac_address = models.CharField(max_length=100,db_index = True)
    ip = models.CharField(max_length=100,db_index = True)
    status = models.IntegerField(default=0, null=True, blank=True, db_index = True)
