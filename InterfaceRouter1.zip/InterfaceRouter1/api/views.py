from django.shortcuts import render
#from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt
from .models import RouterDetails
from .serializers import RouterDetailsSerializer
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import TemplateHTMLRenderer
from django.utils.decorators import method_decorator
from django.views import View
from rest_framework import status
import json

# Create your views here.
#@csrf_exempt
#@method_decorator(csrf_exempt, name = 'dispatch')
class AddDetails(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'add_detail.html'

    def get(self, request):
        return Response({'message' : 'Add data'})

    def post(self, request, *args, **kwargs):
        data = json.loads(request.body)
        print (data,"dataaaaaaaaaaaaaaa")
        serializer = RouterDetailsSerializer(data=data)
        #print (serializer.data,"serializer dataaaaaaaaaaa")
        if serializer.is_valid():
            serializer.save()
            return Response({'message' : 'Details Added successfully'}, status=status.HTTP_200_OK)
        return Response({'message' : 'Not Added'})


class GetUpdateDetails(APIView):
    #permission_classes = (IsAuthenticated,)
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'get_update.html'

    def get(self, request, *args, **kwargs):
        print (kwargs,"/////////////")
        queryset = RouterDetails.objects.get(id=kwargs['id'])
        return Response({'data' : queryset})

    def put(self, request, *args, **kwargs):
        print (kwargs,"/////////////")
        router = RouterDetails.objects.get(id=kwargs['id'])
        data = json.loads(request.body)
        print (data , "data dictttttttt")
        serializer = RouterDetailsSerializer(router, data=data,partial=True)
        if serializer.is_valid():
            serializer.save()
            print('record saved')
            return Response({'message' : 'Details updated successfully'}, status=status.HTTP_200_OK)
        return Response({'message' : 'Not Updated'})

class GetDelDetails(APIView):
    #permission_classes = (IsAuthenticated,)
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'home.html'

    def get(self, request, *args, **kwargs):
        queryset = RouterDetails.objects.filter(status=0)
        return Response({'router_details': queryset})

    def delete(self, request, *args, **kwargs):
        data = RouterDetails.objects.get(id=kwargs['id'])
        # Deleted Items having status 111
        data.status=111
        data.save()
        return Response({'message': 'Data deleted successfully'}, status=status.HTTP_204_NO_CONTENT)
