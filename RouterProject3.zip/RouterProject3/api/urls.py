from django.urls import path, include
from .views import RegisterUser, AddDetails,GetUpdateDetails, GetDelDetails
from . import views
from django.contrib import admin

urlpatterns = [
    #path(r'login',login, name="login"),
    path('register',RegisterUser.as_view()),
    #path(r'login', views.login, name="login"),
    path(r'add_details/', AddDetails.as_view(),name = "add_details"),
    path(r'get_details/<int:id>/', GetUpdateDetails.as_view(),name = "get_details"),
    path(r'update_details/<int:id>/', GetUpdateDetails.as_view(),name = "update_details"),
    path(r'delete/<int:id>/', GetDelDetails.as_view(), name = "delete"),
    path(r'fetch/', GetDelDetails.as_view(),name = "fetch"), 
]
