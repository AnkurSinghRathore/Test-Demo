from django.contrib import admin
from .models import RouterDetails 
# Register your models here.
@admin.register(RouterDetails)
class RouterDetailsAdmin(admin.ModelAdmin):
    list_display = ['id','sapid','hostname','loopback_ipv4','mac_address','ip','status']
